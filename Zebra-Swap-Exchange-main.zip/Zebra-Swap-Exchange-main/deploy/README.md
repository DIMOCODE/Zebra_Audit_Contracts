# wanchai testnet

//NFT liquidity  : 0xeddE5f9E6479f71345d1dC77F8A255C62c13099b
// ZebraSwap : 0xff85b9929B62d078fE76e26e96ceE95e52b4c112

//Wan
//wanBTC
//wanETH
//wanUSDT

// Zebra2.0 , wan mainnet : 0x091a19D021D1a37B7e5d50051c99E1CaedFf8f70
